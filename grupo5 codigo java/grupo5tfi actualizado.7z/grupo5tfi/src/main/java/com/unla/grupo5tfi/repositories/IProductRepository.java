package com.unla.grupo5tfi.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.unla.grupo5tfi.entities.Producto;

@Repository
public interface IProductRepository extends JpaRepository<Producto, Integer> {
}