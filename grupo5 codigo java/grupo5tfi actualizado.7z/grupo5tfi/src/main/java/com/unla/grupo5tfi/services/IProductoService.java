package com.unla.grupo5tfi.services;

import java.util.List;
import java.util.Optional;

import com.unla.grupo5tfi.entities.Producto;

public interface IProductoService {
    List<Producto> getAll();
    Optional<Producto> findById(int id);
    Producto insertOrUpdate(Producto producto);
    boolean remove(int id);
}