mv ../ghsicilianotfi/src/main/java/com/unla/ghsicilianotfi ../ghsicilianotfi/src/main/java/com/unla/"$1"
mv ../ghsicilianotfi/src/test/java/com/unla/ghsicilianotfi ../ghsicilianotfi/src/test/java/com/unla/"$1"
mv ../ghsicilianotfi ../"$1"
