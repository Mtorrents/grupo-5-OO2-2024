# ghsicilianotfi

BOOTSTRAP PARA APRENDIZAJE DE PROYECTOS EN JAVA SPRING

Ejemplo de api con postman: [ghsicilianotfi.postman_collection.json](https://github.com/gussiciliano/ghsicilianotfi/files/15042095/ghsicilianotfi.postman_collection.json)

[Documentación versión 2023 - Spring Boot 3.2.4](https://drive.google.com/file/d/1kaVnsLC_FRtTR2C7gyxHSwlyvZD6rtN6/view?usp=drive_link)
Se recomienda ir a la página 87 sección "Mejoras y actualizaciones importantes" apartado 2024 (y revisar los updates anteriores). 

[Documentación versión 2023 - Spring Boot 3.0.4 (Java 17)](https://drive.google.com/file/d/1JF2yve489njnFPkzLGQZDox8KAx8Pobl/view)
En caso de no haber visto los cambios de la versión 2022 se recomienda ir a la página 87 sección "Mejoras y actualizaciones importantes" apartado 2022. 

[Documentación versión 2022 - Spring Boot 2.6.4 + Lombok + ModelMapper](https://drive.google.com/file/d/1D_KgYmJ1DpbzrqO6-M5NgyqlLHkIayoS/view)
Info de los cambios en la página 87 sección "Mejoras y actualizaciones importantes". 

[Documentación versión 2021 - Spring Boot 2.4.5](https://drive.google.com/file/d/1j2eSstW6NL15ScoZwcX9iQHTSsPf-IDH/view)

[Documentación versión 2020 - Spring Boot 2.2.6](https://drive.google.com/open?id=19jxnlmAU3-NSXgdEj4gbuVsU732-qPed)

[Documentación versión 2018 - Spring Boot 1.5.12](https://drive.google.com/open?id=1DVaVemnIGLifHesSeQScs4lEbW1WMqYt)
